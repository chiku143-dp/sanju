package com.sanju.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var voice: TextToSpeechManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = TextToSpeechManager(this)

        setContent {
            MaterialTheme {
                SanjuScreen()
            }
        }
    }

    @Composable
    private fun SanjuScreen() {
        var text by remember { mutableStateOf("") }
        var showSettings by remember { mutableStateOf(false) }

        val speechLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()

            if (!spoken.isNullOrBlank()) {
                text = spoken
                val reply = "Ji, main sun rahi hoon. Aapne kaha: $spoken"
                voice.speak(reply)
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) startListening(speechLauncher)
        }

        if (showSettings) {
            VoiceSettings(
                manager = voice,
                onBack = { showSettings = false }
            )
            return
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("SANJU 🎀") },
                    actions = {
                        TextButton(onClick = { showSettings = true }) {
                            Text("Voice")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Namaste! Main SANJU hoon 💕", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(16.dp))

                if (text.isNotBlank()) {
                    Text("Aap: $text")
                    Spacer(Modifier.height(24.dp))
                }

                Button(onClick = {
                    val granted = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (granted) startListening(speechLauncher)
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }) {
                    Text("🎤 Bolo SANJU se")
                }

                Spacer(Modifier.height(14.dp))

                OutlinedButton(onClick = {
                    voice.speak("Hello! Main SANJU hoon. Aapki cute assistant.")
                }) {
                    Text("🔊 Voice Test")
                }
            }
        }
    }

    private fun startListening(
        launcher: androidx.activity.result.ActivityResultLauncher<Intent>
    ) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "SANJU ko boliye...")
        }
        launcher.launch(intent)
    }

    @Composable
    private fun VoiceSettings(
        manager: TextToSpeechManager,
        onBack: () -> Unit
    ) {
        val voices = remember { manager.getHindiVoices() }
        var rate by remember { mutableFloatStateOf(manager.getSpeechRate()) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("SANJU Voice 🎀") },
                    navigationIcon = {
                        TextButton(onClick = onBack) { Text("←") }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
            ) {
                Text(
                    "Cute Hindi voice",
                    style = MaterialTheme.typography.headlineSmall
                )

                Spacer(Modifier.height(8.dp))
                Text("Phone ke TTS engine mein available Hindi voices yahan dikhenge.")

                Spacer(Modifier.height(20.dp))

                Text("Voice options")
                LazyColumn {
                    items(voices) { v ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = false,
                                onClick = {
                                    manager.setVoice(v)
                                    manager.speak("Ye SANJU ki voice hai.")
                                }
                            )
                            Text(v.name)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Speech speed: ${String.format("%.2f", rate)}x")
                Slider(
                    value = rate,
                    onValueChange = {
                        rate = it
                        manager.setSpeechRate(it)
                    },
                    valueRange = 0.65f..1.20f
                )

                Spacer(Modifier.height(8.dp))
                Text(
                    "Tip: Agar female Hindi voice available nahi hai, Android ka installed TTS engine default Hindi voice use karega."
                )
            }
        }
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }
}
