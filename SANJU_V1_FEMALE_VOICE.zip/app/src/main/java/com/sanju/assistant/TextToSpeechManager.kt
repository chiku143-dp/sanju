package com.sanju.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var initialized = false
    private var currentVoice: Voice? = null
    private var speechRate = 0.90f

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            initialized = true
            tts?.language = Locale("hi", "IN")
            selectBestHindiVoice()
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(1.08f)
        }
    }

    private fun selectBestHindiVoice() {
        val voices = tts?.voices.orEmpty()
        val hindi = voices.filter {
            it.locale.language.equals("hi", true) &&
            it.locale.country.equals("IN", true)
        }

        // Voice names are engine/device dependent. Prefer names that identify
        // themselves as female, then common Hindi female voice naming patterns.
        currentVoice = hindi.firstOrNull {
            val n = it.name.lowercase()
            n.contains("female") || n.contains("fem") || n.contains("hia")
        } ?: hindi.firstOrNull()

        currentVoice?.let { tts?.voice = it }
    }

    fun speak(text: String) {
        if (!initialized || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SANJU_RESPONSE")
    }

    fun setSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.65f, 1.20f)
        tts?.setSpeechRate(speechRate)
    }

    fun getSpeechRate(): Float = speechRate

    fun getHindiVoices(): List<Voice> {
        return tts?.voices.orEmpty().filter {
            it.locale.language.equals("hi", true) &&
            it.locale.country.equals("IN", true)
        }
    }

    fun setVoice(voice: Voice) {
        currentVoice = voice
        tts?.voice = voice
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
