# SANJU V1.1 — Female Voice

SANJU is a Kotlin + Jetpack Compose Android assistant starter project.

## Included
- Hindi voice input (hi-IN)
- Android Text-to-Speech
- Attempts to select the best available Hindi female voice
- Voice test button
- Hindi voice selection screen
- Speech-speed control
- Cute/soft speech pitch
- Microphone permission handling

## Important
A truly specific "cute girl" voice cannot be guaranteed by Android itself because
the available voices depend on the TTS engine and voices installed on the phone.

For a guaranteed natural female character voice, SANJU can later be connected
to a cloud TTS provider.

## Build
Open the project in Android Studio and let Gradle sync.
Then Build > Build APK(s).
